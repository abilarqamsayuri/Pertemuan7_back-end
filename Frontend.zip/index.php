<?php 
    include_once 'header.php';
?>
<?php 
    include_once 'hero.php';
    include_once 'about.php';
    include_once 'count.php';
    include_once 'feautures.php';
    include_once 'service.php';
    include_once 'pricing.php';
    include_once 'FAQ.php';
?>
<?php 
    include_once 'portofolio.php';
    include_once 'testimonial.php';
    include_once 'team.php';
?>
<?php 
    include_once 'client.php';
    include_once 'recent.php';
    include_once 'contact.php';
?>
<?php 
    include_once 'footer.php';
?>